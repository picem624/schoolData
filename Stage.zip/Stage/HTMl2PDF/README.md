# CIGL-Worksheet

# Security for webserver

Stuff to consoder when building the production server.

- who can access the site
- how to manage user logins and device access
    - https://www.cyberciti.biz/tips/iptables-mac-address-filtering.html


# TO-DO

   - [ ] Add images and make then render with the JS code
   - [ ] Make everything fit into one A4 page
   - [ ] finish css
   - [ ] test live version with actual people
