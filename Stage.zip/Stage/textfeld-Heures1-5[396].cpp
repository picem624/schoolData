#include <string>;
using namespace std;
// Stunden pr�fung und berechnung Textfeld Heures1- Heures5

// Heures1
var noms1 = "";
var quelle = null;

var kalkul = this.getField("Kalkul_stunde");

quelle = this.getField("Noms1");

if ((quelle.value != " ") && (quelle.value.length > 0))
{
	this.getField("Heures1").value = kalkul.value;
}

// Heures2
var noms2 = "";
var quelle = null;

var kalkul = this.getField("Kalkul_stunde");

quelle = this.getField("Noms2");

if ((quelle.value != " ") && (quelle.value.length > 0))
{
	this.getField("Heures2").value = kalkul.value;
}

// Heures3
var noms3 = "";
var quelle = null;

var kalkul = this.getField("Kalkul_stunde");

quelle = this.getField("Noms3");

if ((quelle.value != " ") && (quelle.value.length > 0))
{
	this.getField("Heures3").value = kalkul.value;
}

// Heures4
var noms4 = "";
var quelle = null;

var kalkul = this.getField("Kalkul_stunde");

quelle = this.getField("Noms4");

if ((quelle.value != " ") && (quelle.value.length > 0))
{
	this.getField("Heures4").value = kalkul.value;
}

// Heures5
var noms5 = "";
var quelle = null;

var kalkul = this.getField("Kalkul_stunde");

quelle = this.getField("Noms5");

if ((quelle.value != " ") && (quelle.value.length > 0))
{
	this.getField("Heures5").value = kalkul.value;
}

// calculate total hours 
// initialise all needed variables
var textfield = this.getField("Beginn_stunde").value;
var textfield2 = this.getField("Ende_stunde").value;
var strgTextfield = textfield.toString();
var strgTextfield2 = textfield2.toString();
var strgBeginHours = "";
var strgBeginMins = "";
var strgEndHours = "";
var strgEndMins = "";
var intBeginHours = 0;
var intBeginMins = 0;
var intEndHours = 0;
var intEndMins = 0;

// separate the Begintime value into two strings. Hours and mins.

for (var i = 0; i < strgTextfield.length; i++) {
	if (strgTextfield[i] != ":") {
		if (i < 2) {
			strgBeginHours += strgTextfield[i];
		}
		else {
			strgBeginMins += strgTextfield[i];
		}
	}
}
// separate the Endtime value into two strings. Hours and mins.

for (var i = 0; i < strgTextfield2.length; i++) {
	if (strgTextfield2[i] != ":") {
		if (i < 2) {
			strgEndHours += strgTextfield2[i];
		}
		else {
			strgEndMins += strgTextfield2[i];
		}
	}
}
// set the corresponding integer values for each time segment (hours, mins / beginning , end)

intBeginHours = parseInt(strgBeginHours);
if (strgBeginMins == "00") {
	intBeginMins = .0;

}
else
intBeginMins = parseInt(strgBeginMins);


intEndHours = parseInt(strgEndHours);
if (strgEndMins == "00") {
	intEndMins = 0;
}
else
intEndMins = parseInt(strgEndMins);
totalTime(intBeginHours, intBeginMins, intEndHours, intEndMins);

function totalTime(beginHours, beginMins, endHours, endMins) {

	var totalMins = 0;
	var totalHours = 0;
	if (beginMins == endMins) {
		totalHours = endHours - beginHours;
		this.getField("Kalkul_stunde").value = totalHours;
	}


	else if (endMins == 0 && beginMins != 0) {

		endMins = 60;
		totalMins = endMins - beginMins;
		totalHours = endHours - beginHours - 1;
		if (totalMins < 10) {
			this.getField("Kalkul_stunde").value = totalHours + " : " + " 0" + totalMins;
		}
		else
			this.getField("Kalkul_stunde").value = totalHours + " : " + totalMins;
	}
	else if (beginMins == 0 && endMins != 0) {

		totalMins = endMins;
		totalHours = endHours - beginHours;

		if (totalMins < 10) {
			this.getField("Kalkul_stunde").value = totalHours + " : " + " 0" + totalMins;
		}
		else
			this.getField("Kalkul_stunde").value = totalHours + " : " + totalMins;


	}
	else if (beginMins != 0 && endMins != 0) {
		if (beginMins > endMins) {
			var tempMins = beginMins - endMins;
			totalMins = 60 - tempMins;
			totalHours = endHours - beginHours - 1;

			if (totalMins > 60) {
				totalMins -= 60;
			}
			else if (totalMins == 60) {
				totalMins = 0;
			}
		}
		else {
			totalMins = endMins - beginMins;
			totalHours = endHours - beginHours;
		}


		if (totalMins < 10) {
			this.getField("Kalkul_stunde").value = totalHours + " : " + " 0" + totalMins;
		}
		else
			this.getField("Kalkul_stunde").value = totalHours + " : " + totalMins;


	}
}
}

// calculate the sum of all the array elements.

var parent = this.getField("travail");
var children = parent.getArray();

var totalHours = 0;
var totalMins = 0;
var mins = 0;


for (var i = 0; i < children.length; i++) {
	if (children[i].value != 0) {
		totalMins += children[i].value;
	}
}
if (totalMins >= 60 || totalMins == 60) {
	totalHours += totalMins / 60;
	totalMins = totalMins % 60;
}


if (totalMins < 10) {

	this.getField("Kalkul_stunde").value = parseInt(totalHours) + ":" + "0" + parseInt(totalMins);


}
else if (totalMins == 0) {
	this.getField("Kalkul_stunde").value = parseInt(totalHours) + ":" + "00";

}
else {
	this.getField("Kalkul_stunde").value = parseInt(totalHours) + ":" + parseInt(totalMins);



}
totalMins = 0;


// set checkbox true where there is a amount of time.

var parent = this.getField("travail");
var checkBoxParent = this.getField("checkBox");
var checkBoxChildren = checkBoxParent.getArray();
var child = parent.getArray();


for (var i = 0; i < child.length; i++) {
	if (child[i].value == NULL)
	{
		checkBoxChildren[i].checkThisBox(0, false)
	}
	else
	{
		checkBoxChildren[i].checkThisBox(0, true);


	}


}
// automatically set value in dropdoown material list, when corresponding  checkbox is checked.
var material = this.getField("Matlist");
var materialSlots = material.getArray();
var Option = ["tondeuse", "/"];
var checkBox = this.getField("checkBox.1");


if (checkBox.isBoxChecked(0) == false) {
	app.alert("checked");
	for (var i = 0; i < 4; i++) {
		app.alert(materialSlots[i].value);
		if (materialSlots[i].value == "/") {
			materialSlots[i].setItems(Option);
		}

	}
}
else {
	app.alert("not Checked");
	Option = ["/", "D�brouss", "Tandeuse", "Perceuse", "Souffleur", "Scarificateur", "Taille-Haie", "Tran�onneuse"]

		for (var i = 0; i < 4; i++) {
			app.alert(materialSlots[i].value);
			if (materialSlots[i].value == "tondeuse") {
				materialSlots[i].setItems(Option);
			}
		}
}
//when entering the text box check the checkbox + add the machine to the list underneath.

var checkbox = this.getField("checkBox.1");

checkbox.checkThisBox(0, true);

var material = this.getField("Matlist");
var materialSlots = material.getArray();
var Option = ["tondeuse", "/"];
var checkBox = this.getField("checkBox.1");


for (var i = 0; i < 4; i++) {
	if (materialSlots[i].value == "/") {
		materialSlots[i].setItems(Option);


	}

}

var formDate = this.getField("Date01").value;
global.date = global.date;
var strDate = global.date.toString();
var strFormDate = formDate.toString();
global.serialNumber = global.serialNumber;
global.setPersistent("serialNumber", true);
if (strDate == strFormDate) {
	global.serialNumber += 1;
	this.getField("numero").value = formDate + " - " + global.serialNumber;

}

else {
	global.date = formDate;
	global.serialNumber = 1;
	this.getField("numero").value = formDate + " - " + global.serialNumber;

}

var formDate = this.getField("Date01").value;
var date = date;
var strFormDate = formDate.toString();
var serialNumber = serialNumber;
if (date == formDate) {
	serialNumber += 1;
	this.getField("numero").value = formDate + " - " + serialNumber;

}

else {
	date = formDate;
	serialNumber = 1;
	this.getField("numero").value = formDate + " - " + serialNumber;


}


// normal serialNumber
var date = this.getField("Date01").valueAsString.substr(-4);
var year = year;

var serieNummer = this.getField("numero").value;


if (year == date) {
	serieNummer += 1;
	this.getField("numero").value = serieNummer;
}
else {
	serieNummer = 1;
	year = date;
	this.getField("numero").value = serieNummer;
}


// global serial number;
var date = this.getField("Date01").valueAsString.substr(-4);
global.year = global.year;
global.setPersistent("year", true);

global.serieNummer = global.serieNummer;
global.setPersistent("serieNummer", true);


if (global.year == date) {
	global.serieNummer += 1;
	this.getField("numero").value = global.serieNummer;
}
else {
	global.serieNummer = 1;
	global.year = date;
	this.getField("numero").value = global.serieNummer;
}














