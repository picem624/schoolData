#include "CardDeck.h"



Card *CardDeck::dealACard()
{
	int random = rand();
	random %= 52;
	if (Deck[random]->isAlreadyUsed == false) {
		Card *tempCard = Deck[random];
		Deck[random]->isAlreadyUsed = true;
		return tempCard;
	}
	else {
		return dealACard();
	}
}

void CardDeck::Delete()
{
	for (int i = 0; i < 52; i++) {
		delete[] Deck[i % 13 + 2];
	}
	delete[]Deck;
}


CardDeck::CardDeck()
{
	
	
	for (int i = 0; i < 52; i++) {
		Deck[i] = new Card();
		Deck[i]->setValue(i % 13 + 2);

		switch (i / 13) {
		case 0:
			Deck[i]->setSuit(spades);
			break;
		case 1:
			Deck[i]->setSuit(diamonds);
			break;
		case 2:
			Deck[i]->setSuit(clubs);
			break;
		case 3:
			Deck[i]->setSuit(hearts);
		}
	}
}

void CardDeck::randomSeed()
{
	srand(time(0));
}


