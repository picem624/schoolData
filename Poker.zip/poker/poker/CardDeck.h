#pragma once
#include "Card.h"
#include<stdlib.h>
#include<time.h>

class CardDeck
{
public:
	
	Card *dealACard();
	void Delete();
	CardDeck();
	void randomSeed();
	
private:
	
	Card *Deck[52];
};

