#include "Player.h"

int Player::getBet()
{
    return bet;
}

void Player::setBet(int bet)
{
    this->bet = bet;
}

Player::Player(string name,int money, bool isSmallBlind)
{
    this->Name = name;
    this->Money = money;
    this->isSmallBlind = isSmallBlind;
    hand = royalFlush;
    handRank = 0;
    bet = 0;
    isAllIn = false;
    highestCard = new Card();
    for (int i = 0; i < 2; i++) {
        cards[i] = new Card();
    }
    for (int i = 0; i < 7; i++) {
        handtoDisplay[i] = new Card();
    }

   
}

bool Player::getAllIn()
{
    return isAllIn;
}

void Player::setSmallBlind(bool boolean)
{
    isSmallBlind = boolean;
}

bool Player::getSmallBlind()
{
    return isSmallBlind;
}

void Player::setAllIn(bool boolean)
{
    this->isAllIn = boolean;
}

void Player::setHandRankType(handType type)
{
    hand = type;
}

handType Player::getHandRankType()
{
    return hand;
}

void Player::setHandRanking(int rank)
{
    handRank = rank;
}

int Player::getHandRanking()
{
    return handRank;
}

void Player::setMoney(int money)
{
    this->Money = money;
}

int Player::getMoney()
{
    return Money;
}

void Player::setName(string Name)
{
    this->Name = Name;
}

string Player::getName()
{
    return this->Name;
}

Card Player::getCardArray(int index)
{
    return *cards[index];
}

Card* Player::getCardArrayB(int index)
{
    return cards[index];
}

void Player::setCardInArray(int i, Card *card)
{
    this->cards[i] = card;
}

bool Player::getHasFold()
{
    return hasFold;
}

void Player::setHasFold(bool boolean)
{
    hasFold = boolean;
}

void Player::setHighestCard(Card* card)
{
    highestCard = card;
}

Card* Player::getHighestCard()
{
    return highestCard;
}

void Player::setTotalbet(int bet)
{
    totalBet = bet;
}

int Player::getTotalBet()
{
    return totalBet;
}

void Player::setHandsValue(int value)
{
    handsValue = value;
}

int Player::getHandsValue()
{
    return handsValue;
}

void Player::setHandArray(int i, Card* card)
{
    handtoDisplay[i] = card;
}

Card *Player::getHandsArray(int i)
{
    return handtoDisplay[i];
}
