#pragma once
#include"Player.h";
#include"CardDeck.h";
#include<sstream>;
class Game
{
public:
	Game();
	void PlayGame();
	
	
private:
	Player *players[2];
	Card* tableDeck[7];
	Player *highestBider;
	int highestBet;
	int Pot;
	bool lastCardUncovered;
	CardDeck *Deck;
	Player* winner;

	~Game();
	void bubbleSort();
	void AnnounceWinner(Player* p);
	void splitThePot(string name);
	void determineHand(Player* p);
	string BettingRound();
	string CheckHowManyPlayersAllIn();

	// Display functions
	void DisplayChoice();
	void DisplayCards(Player* p);
	void DisplayCommunityCards();
	void DisplayStacks(Player* p);
	string DisplayHandRank(Player* p);

	//small checks
	bool checkMoney(Player* p, int value);
	bool checkIfRaiseValid(Player *p, int newBet);

	// choices
	void raise(Player *p, int newBet);
	void fold(Player*p);
	void goAllIn(Player *p);
	void check(Player *p);

	// resets
	void ResetValuesSmallRound();
	void ResetValuesBigROund();

	// compare funtions
	bool compareBets(Player* p1, Player* p2);
	string compareHands();

    // setters & getters
	void SetHighestBidder(Player *p);
	void setHighestBet(int bet);
	void setHandRank(Player* p, int rank);
	void setHandType(Player* p, handType type);
	int getHandRank(Player p);
	int getHighestBet();
	handType getHandRankType(Player* p);
	Player getHighestBidder();

	// set community cards in table
	void uncoverNextCard();
	void uncoverAllCards();

	// hands
	bool RoyalFlush();
	bool StraightFlush();
	bool FourOfAKind();
	bool FullHouse();
	bool Straight();
	bool Flush();
	bool ThreeOfAKind();
	bool TwoPair();
	bool Pair();
	bool HighestCard();


};

