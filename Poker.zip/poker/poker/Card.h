#pragma once
#include <iostream>
enum Suit {undefined, diamonds, clubs, hearts, spades };

class Card
{
public:
	Card();
	void Display();
	void setValue(int value);
	void setSuit(Suit suit);
	int getValue();
	Suit getSuit();
	bool isAlreadyUsed;

private:
	int value;
	Suit suit;
};

