#include "Game.h"


Game::Game()
{
	highestBet = 0;
	Deck = new CardDeck();
	Deck->randomSeed();
	Pot = 0;
	highestBider = players[0];
	lastCardUncovered = false;
	winner = new Player(" ", 0, false);

	for (int i = 0; i <= 1; i++) {
		if (i == 0) {
			players[i] = new Player("Player1", 2000, true);
		}
		else {
			players[i] = new Player("Player2", 200, false);

		}
	}
	for (int i = 0; i < 7; i++) {
		tableDeck[i] = new Card();
		tableDeck[i]->setValue(0);
	}


}

void Game::PlayGame()
{
	bool gameOver = false;
	string word;
	string strWinner;
	while (!gameOver) {
		if (players[0]->getSmallBlind() == true) {
			players[0]->setSmallBlind(false);
			players[1]->setSmallBlind(true);
		}
		else {
			players[1]->setSmallBlind(false);
			players[0]->setSmallBlind(true);
		}
		for (int j = 0; j < 2; j++) {
			if (players[j]->getSmallBlind() == true) {
				players[j]->setBet(25);
			}
			else {
				players[j]->setBet(50);
				highestBet = 50;
			}
		}

		for (int j = 0; j < 4; j++) {
			for (int n = 0; n < 2; n++) {
				if (j < 2) {
					players[0]->setCardInArray(n, Deck->dealACard());
				}
				else
					players[1]->setCardInArray(n, Deck->dealACard());
			}
		}
		if (players[0]->getCardArray(0).getValue() > players[0]->getCardArray(1).getValue())
			players[0]->setHighestCard(players[0]->getCardArrayB(0));
		else if (players[0]->getCardArray(0).getValue() == players[0]->getCardArray(1).getValue())
			players[0]->setHighestCard(players[0]->getCardArrayB(0));
		else
			players[0]->setHighestCard(players[0]->getCardArrayB(1));


		if (players[1]->getCardArray(0).getValue() > players[1]->getCardArray(1).getValue())
			players[1]->setHighestCard(players[0]->getCardArrayB(0));
		else if (players[1]->getCardArray(0).getValue() == players[1]->getCardArray(1).getValue())
			players[1]->setHighestCard(players[1]->getCardArrayB(0));
		else
			players[1]->setHighestCard(players[1]->getCardArrayB(1));



		while (!lastCardUncovered) {
			word = BettingRound();
			if (word == "equal") {
				uncoverNextCard();
				Pot = Pot + players[0]->getBet() + players[1]->getBet();
				ResetValuesSmallRound();
			}
			else if (word == "all") {
				uncoverAllCards();
				Pot = players[0]->getBet() + players[1]->getBet();

			}
			else if (word == "fold") {
				break;
			}
		}
		if (word == "fold") {
			if (players[0]->getHasFold()) {
				AnnounceWinner(players[1]);
				winner = players[1];
				winner->setMoney(winner->getMoney() + Pot);
				Pot = 0;
			}
			else {
				AnnounceWinner(players[0]);
				winner = players[1];
				winner->setMoney(winner->getMoney() + Pot);

			}
		}
		else {
			BettingRound();
			for (int j = 0; j < 2; j++) {
				if (j < 1) {
					tableDeck[5] = players[j]->getCardArrayB(0);
					tableDeck[6] = players[j]->getCardArrayB(1);
				}
				else {
					for (int n = 0; n < 7; n++) {
						if (tableDeck[n] == players[0]->getCardArrayB(0))
							tableDeck[n] = players[j]->getCardArrayB(0);
						else if (tableDeck[n] == players[0]->getCardArrayB(1))
							tableDeck[n] = players[j]->getCardArrayB(1);

					}

				}
				bubbleSort();
				determineHand(players[j]);

			}
			strWinner = compareHands();
			if (strWinner == players[0]->getName())
				winner = players[0];
			else if (strWinner == players[1]->getName())
				winner = players[1];
			else
				winner->setName(strWinner);
			AnnounceWinner(winner);
			splitThePot(winner->getName());


		}
		ResetValuesBigROund();
		if (players[0]->getMoney() <= 0 || players[1]->getMoney() <= 0)
			gameOver = true;
	}
}

Game::~Game()
{
	Deck->Delete();
	delete[] players[0];
	delete[] players[1];
	delete[]players;

	for (int i = 0; i < 7; i++) {
		delete[] tableDeck[i];
	}
	delete[] tableDeck;

}

void Game::AnnounceWinner(Player* p)
{
	Player* p1 = new Player(" ", 0, false);
	Player* p2 = new Player(" ", 0, false);
	if (players[0] == p) {
		winner = players[0];
		p2 = players[1];
	}
	else {
		winner = players[1];
		p2 = players[0];
	}
	if (p->getName() == "both") {
		cout << "you have the exact same hand /	splitting the Pot";
	}
	else if (winner->getHasFold() == true)
		cout << p2->getName() << " wins because the other player folded0" << endl << endl;
	else if (p2->getHasFold() == true)
		cout << p2->getName() << " wins because the other player folded0" << endl << endl;
	else {
		cout << "the winner is " << p->getName() << " with a the winnig hand " << DisplayHandRank(p) << endl << endl;
		DisplayCards(winner);
		cout << " player loses with  ";
		DisplayHandRank(p2);
		cout << endl;
		DisplayCards(p2);
	}
}


void Game::bubbleSort()
{
	int n = sizeof(tableDeck) / sizeof(tableDeck[0]);
	int i, j;
	for (i = 0; i < n - 1; i++)
		for (j = 0; j < n - i - 1; j++)
			if (tableDeck[j]->getValue() > tableDeck[j + 1]->getValue())
				swap(tableDeck[j], tableDeck[j + 1]);

}


void Game::splitThePot(string name)
{
	if (name != "both") {
		Player* p2 = new Player(" ", 0, false);
		string word = "";
		if (players[0]->getName() == name) {
			winner = players[0];
			p2 = players[1];
		}
		else {
			winner = players[1];
			p2 = players[0];
		}
		word = CheckHowManyPlayersAllIn();

		if (word == "all") {
			if (Pot >= winner->getTotalBet() * 2) {
				winner->setMoney(winner->getMoney() + winner->getTotalBet() * 2);
				Pot -= winner->getTotalBet() * 2;
				p2->setMoney(Pot);
			}
			else {
				winner->setMoney(winner->getMoney() + Pot);


			}
		}
		else if (word == "some") {
			if (winner->getAllIn() == true) {
				winner->setMoney(winner->getMoney() + (winner->getTotalBet() * 2));
				Pot -= winner->getTotalBet() * 2;
				p2->setMoney(p2->getMoney() + Pot);
			}
			else {
				winner->setMoney(winner->getMoney() + Pot);

			}
		}
		else {
			winner->setMoney(winner->getMoney() + Pot);
		}
	}
	else {
		players[0]->setMoney(players[0]->getMoney() + Pot / 2);
		players[1]->setMoney(players[1]->getMoney() + Pot / 2);

	}


	Pot = 0;
}

void Game::determineHand(Player* p)
{
	for (int i = 0; i < 7; i++) {
		p->setHandsValue(p->getHandsValue() + tableDeck[i]->getValue());
		p->setHandArray(i, tableDeck[i]);
	}
	if (RoyalFlush()) {
		setHandRank(p, 10);
		setHandType(p, royalFlush);
		return;
	}
	else if (StraightFlush()) {
		setHandRank(p, 9);
		setHandType(p, straightFlush);
		return;
	}
	else if (FourOfAKind()) {
		setHandRank(p, 8);
		setHandType(p, fourOfAKind);
		return;
	}
	else if (FullHouse()) {
		setHandRank(p, 7);
		setHandType(p, fullHouse);
		return;
	}
	else if (Flush()) {
		setHandRank(p, 6);
		setHandType(p, FLUSH);
		return;
	}
	else if (Straight()) {
		setHandRank(p, 5);
		setHandType(p, straight);
		return;
	}
	else if (ThreeOfAKind()) {
		setHandRank(p, 4);
		setHandType(p, threeOfAKind);
		return;
	}
	else if (TwoPair()) {
		setHandRank(p, 3);
		setHandType(p, twoPair);
		return;
	}
	else if (Pair()) {
		setHandRank(p, 2);
		setHandType(p, PAIR);
		return;

	}
	else {
		setHandRank(p, 1);
		setHandType(p, highestCard);
		return;

	}
}


string Game::BettingRound()
{
	stringstream ss;
	string command;
	string value;
	string word = " ";
	bool agree = false;
	bool commandExecuted = false;


	while (agree == false) {

		for (int i = 0; i < 2; i++) {
			if (players[i]->getAllIn() == true) {}
			else {
				DisplayCommunityCards();
				commandExecuted = false;
				for (int k = 0; k < 20; k++) {
					cout << " ---";
				}
				cout << endl;
				cout << "here are your cards " << players[i]->getName() << endl;

				for (int j = 0; j < 2; j++) {
					players[i]->getCardArray(j).Display();
					cout << "   ";
				}
				cout << endl << endl;
				cout << "your Money " << players[i]->getMoney() << "�" << "		your bet: " << players[i]->getBet() << "		highest Bet = " << highestBet << "	the Pot " << Pot << endl << endl;

				while (!commandExecuted) {
					DisplayChoice();
					cout << endl;
					cin >> command;
					cout << endl << endl;

					if (command == "raise" || command == "Raise") {
						if (checkMoney(players[i], 1)) {
							int intValue = 0;
							for (int k = 0; k < 20; k++) {
								cout << " ---";
							}
							cout << endl;
							while (!checkIfRaiseValid(players[i], intValue)) {
								if (intValue == 0) {
									cout << " Enter the value you want to bet. Please only input an integer value bigger than the highest Bet" << endl
										<< "	your Money " << players[i]->getMoney() << "�" << "		your bet: " << players[i]->getBet() << "		highest Bet = " << highestBet << "	the Pot " << Pot << endl << endl
										<< "Enter your bet amount:	  ";
									cin >> value;
									cout << endl << endl;
									intValue = stoi(value);
								}
								else if (!checkIfRaiseValid(players[i], intValue)) {
									cout << " enter a bigger value than the highest bet: " << highestBet << " :  ";
									getline(cin, value);
									intValue = stoi(value);
								}
							}
							raise(players[i], intValue);
							commandExecuted = true;
							setHighestBet(players[i]->getBet());
							SetHighestBidder(players[i]);
							DisplayStacks(players[i]);
						}
						else {
							cout << " You do not have enough Money to raise the bet above the highest bet";
							cout << endl << " these are your options :" << endl << "fold		ALL-IN		Check/ Call";
							cin >> command;;
						}
					}
					else if (command == "check" || command == "Check") {
						if (checkMoney(players[i], 2)) {
							check(players[i]);
							commandExecuted = true;
							DisplayStacks(players[i]);
						}
						else {
							cout << " You do not have enough Money to place the qual amount as the  highest bet";
							cout << endl << " these are your options :" << endl << "fold		ALL-IN";
							cin >> command;
						}
					}
					else if (command == "fold") {
						fold(players[i]);
						commandExecuted = true;
						return "fold";

					}
					else if (command == "all") {
						goAllIn(players[i]);
						commandExecuted = true;
						DisplayStacks(players[i]);
					}
					else
						cout << " write the right command" << endl;
				}
			}
		}

		if (compareBets(players[0], players[1])) {
			agree = true;
			if (word == "some")
				return "all";
			if (!lastCardUncovered) {
				cout << "The bets are equal. let's uncover the next card(s)" << endl;
				for (int k = 0; k < 20; k++) {
					cout << " ---";
				}
				cout << endl << endl;
				return "equal";

			}
			else {
				cout << "let's see who is the winner " << endl << endl;
				for (int k = 0; k < 20; k++) {
					cout << " ---";
				}
				cout << endl;
				return "equal";
			}


		}
		else {
			word = CheckHowManyPlayersAllIn();
			if (word == "none") {
				agree = false;
			}
			else if (word == "all") {
				agree = true;
				return "all";
			}
			else if (word == "some") {
				if (highestBider->getAllIn() == true) {
					agree = false;
				}
				else
					return "all";
			}

		}

	}
}

string Game::CheckHowManyPlayersAllIn()
{
	string temp = " ";
	if (players[0]->getAllIn() && players[1]->getAllIn()) {
		return "all";
	}
	else if (players[0]->getAllIn() || players[1]->getAllIn()) {
		return "some";
	}
	else {
		return "none";
	}
}

int Game::getHighestBet()
{
	return highestBet;
}

void Game::DisplayChoice()
{
	cout << "you can choose between the 4 different commands " << endl << "Raise   Check   Fold   all" << endl;
}
void Game::DisplayCards(Player* p)
{
	cout << " here are the al the cards of " << p->getName() << endl;
	for (int i = 0; i < 7; i++) {
		if (p->getHandsArray(i)->getValue() != 0) {
			p->getHandsArray(i)->Display();
			cout << "		";
		}
	}
	cout << endl << endl;

}

void Game::DisplayCommunityCards()
{
	cout << " here are the current community Cards" << endl << endl;
	cout << "	";
	for (int i = 0; i < 7; i++) {
		if (tableDeck[i]->getValue() != 0) {
			tableDeck[i]->Display();
			cout << "	";
		}

	}
	cout << endl << endl;
}

void Game::DisplayStacks(Player* p)
{
	for (int k = 0; k < 20; k++) {
		cout << " ---";
	}
	cout << endl;
	cout << "	your Money " << p->getMoney() << "�" << "		your bet: " << p->getBet() << "		highest Bet = " << highestBet << "	the Pot " << Pot << endl << endl;
	cout << " press Enter button to continue" << endl;
	cin.ignore();
	system("cls");
}

string Game::DisplayHandRank(Player* p)
{
	int rank = p->getHandRanking();
	switch (rank) {
	case 1:
		return "highest Card";
	case 2:
		return "Pair";
	case 3:
		return "two Pair";

	case 4:
		return "three of a kind";
	case 5:
		return "straight";
	case 6:
		return "flush";
	case 7:
		return "full house";
	case 8:
		return "four of a kind";
	case 9:
		return "straight Flush";
	case 10:
		return "royal Flush";
	}
}


bool Game::checkMoney(Player* p, int value)
{
	switch (value) {
	case 1:
		if (p->getMoney() + p->getBet() > highestBet)
			return true;
		else
			return false;
		break;

	case 2:
		if (p->getMoney() + p->getBet() >= highestBet)
			return true;
		else
			return false;
		break;
	}

}

bool Game::checkIfRaiseValid(Player* p, int newBet)
{

	if (p->getBet() + newBet > highestBet) {
		return true;
	}
	if (p->getBet() + newBet <= highestBet)
		return false;
}


void Game::raise(Player* p, int newBet)
{

	int tempBet = p->getBet() + newBet;
	p->setBet(tempBet);
	p->setMoney(p->getMoney() - newBet);
	p->setTotalbet(p->getTotalBet() + p->getBet());

}

void Game::fold(Player* p)
{
	p->setHasFold(true);

}

void Game::goAllIn(Player* p)
{
	p->setBet(p->getBet() + p->getMoney());
	p->setTotalbet(p->getTotalBet() + p->getBet());
	p->setMoney(0);
	p->setAllIn(true);

	if (p->getBet() > highestBet) {
		SetHighestBidder(p);
		setHighestBet(p->getBet());
	}
}

void Game::check(Player* p)
{
	int difference = highestBet - p->getBet();
	p->setBet(p->getBet() + difference);
	p->setMoney(p->getMoney() - difference);
	p->setTotalbet(p->getTotalBet() + p->getBet());

}

void Game::ResetValuesSmallRound()
{
	for (int i = 0; i < 2; i++) {
		players[i]->setBet(0);

	}
	highestBet = 0;

}

void Game::ResetValuesBigROund()
{
	Card* neutralCard = new Card();
	neutralCard->setValue(0);
	for (int i = 0; i < 2; i++) {
		players[i]->setBet(0);
		players[i]->setAllIn(false);
		players[i]->setCardInArray(i, neutralCard);
		players[i]->setHasFold(false);
		players[i]->setTotalbet(0);
		for (int j = 0; j < 7; j++) {
			players[i]->setHandArray(i, neutralCard);
		}


	}
	for (int i = 0; i < 7; i++) {
		tableDeck[i] = neutralCard;
	}
	highestBet = 0;
	lastCardUncovered = false;
	Pot = 0;
	Deck = new CardDeck();

}


bool Game::compareBets(Player* p1, Player* p2)
{
	if (p1->getBet() == p2->getBet()) {
		return true;
	}
	else {
		return false;
	}
}


string Game::compareHands()
{

	int value1 = 0, value2 = 0;
	if (players[0]->getHandRanking() > players[1]->getHandRanking())
		return players[0]->getName();
	if (players[1]->getHandRanking() > players[0]->getHandRanking())
		return players[1]->getName();
	if (players[0]->getHandRanking() == players[1]->getHandRanking())
		if (players[0]->getHandsValue() > players[1]->getHandsValue())
			return players[0]->getName();
		else if (players[0]->getHandsValue() < players[1]->getHandsValue())
			return players[1]->getName();
		else
			return "both";
}

void Game::SetHighestBidder(Player* p)
{
	highestBider = p;
}

void Game::setHighestBet(int bet)
{
	highestBet = bet;
}


void Game::setHandRank(Player* p, int rank)
{
	p->setHandRanking(rank);
}

void Game::setHandType(Player* p, handType type)
{
	p->setHandRankType(type);
}

handType Game::getHandRankType(Player* p)
{
	return p->getHandRankType();
}

int Game::getHandRank(Player p)
{
	return p.getHandRanking();
}

Player Game::getHighestBidder()
{
	return *highestBider;
}


void Game::uncoverNextCard()
{
	if (tableDeck[0]->getValue() == NULL) {
		for (int i = 0; i < 3; i++) {
			tableDeck[i] = Deck->dealACard();
		}

	}
	else if (tableDeck[3]->getValue() == NULL) {
		tableDeck[3] = Deck->dealACard();

	}

	else if (tableDeck[4]->getValue() == NULL)
	{
		tableDeck[4] = Deck->dealACard();
		lastCardUncovered = true;

	}
}


void Game::uncoverAllCards()
{
	int counter = 0;
	for (int i = 0; i < 5; i++) {
		if (tableDeck[i]->getValue() == 0) {
			tableDeck[i] = Deck->dealACard();
			tableDeck[i]->Display();
			cout << "		";

		}
		else {
			tableDeck[i]->Display();
			cout << "		";


		}
	}
	cout << endl << endl;
	lastCardUncovered = true;
}


bool Game::RoyalFlush()
{
	bool straight = true;
	bool flush = false;
	Suit SuitArray[5] = {};
	int counter = 0;
	while (straight && counter < 4) {
		for (int i = 2; i <= 5; i++) {
			for (int j = i + 1; j <= i + 1; j++) {
				if (tableDeck[i]->getValue() + 1 == tableDeck[j]->getValue()) {
					straight = true;
					counter++;
					if (i == 2) {
						SuitArray[0] = tableDeck[i]->getSuit();
						SuitArray[1] = tableDeck[j]->getSuit();
					}
					else {
						SuitArray[i - 1] = tableDeck[j]->getSuit();
					}
				}

				else if (tableDeck[i]->getValue() == tableDeck[j]->getValue()) {
					counter = counter;

				}
				else {
					straight = false;
					return straight;
				}
			}

		}
	}
	if (counter != 4) {
		straight = false;
		return straight;
	}
	if (SuitArray[0] == SuitArray[1] == SuitArray[2] == SuitArray[3] == SuitArray[4]) {
		flush = true;
	}
	if (flush && straight && tableDeck[2]->getValue() == 10) {
		return true;
	}
	else
		return false;

}






bool Game::StraightFlush()
{
	bool straight = true;
	bool flush = false;
	Suit SuitArray[7] = {};
	int counter = 0;
	int SuitCounter = 0;


	while (straight && counter < 4) {
		for (int i = 0; i <= 5; i++) {
			for (int j = i + 1; j <= i + 1; j++) {
				if (tableDeck[i]->getValue() + 1 == tableDeck[j]->getValue()) {
					straight = true;
					counter++;
					if (i == 0) {
						SuitArray[i] = tableDeck[i]->getSuit();
						SuitArray[j] = tableDeck[j]->getSuit();
					}
					else {
						SuitArray[j] = tableDeck[j]->getSuit();
					}
				}

				else if (tableDeck[i]->getValue() == tableDeck[j]->getValue()) {
					counter = counter;

				}
				else {
					straight = false;
					return straight;
				}
			}

		}
	}
	if (counter < 4) {
		straight = false;
		return straight;
	}
	for (int i = 0; i < 7; i++) {
		if (SuitCounter == 5) {
			flush = true;
			break;
		}
		SuitCounter = 0;
		for (int j = 0; j < 7; j++) {
			if (SuitArray[i] != undefined && SuitArray[j] != undefined) {
				if (SuitArray[i] == SuitArray[j]) {
					SuitCounter++;
				}
			}
		}
	}

	if (flush && straight) {
		return true;
	}
	else
		return false;

}


bool Game::FourOfAKind()
{

	bool fourOfKind = false;
	int counter = 0;

	for (int i = 0; i < 7; i++) {
		if (counter == 4) {
			fourOfKind = true;
			break;
		}
		counter = 0;

		for (int j = 0; j < 7; j++) {
			if (tableDeck[i]->getValue() == tableDeck[j]->getValue()) {
				counter++;
			}
			else
				counter = counter;
		}
	}
	return fourOfKind;
}



bool Game::FullHouse()
{
	bool threeOfAKind = false;
	bool pair = false;
	int counter = 0;
	int numbers[2] = { 0 };

	for (int i = 0; i < 7; i++) {
		if (counter == 3) {
			threeOfAKind = true;


		}
		else if (counter == 2) {
			pair = true;
		}

		counter = 0;

		for (int j = 0; j < 7; j++) {
			if (tableDeck[i]->getValue() == tableDeck[j]->getValue()) {
				counter++;
			}
			else
				counter = counter;
		}
	}

	if (threeOfAKind && pair)
		return true;
	else
		return false;
}

bool Game::Straight()
{
	bool straight = true;
	int counter = 0;
	while (straight && counter < 4) {
		for (int i = 0; i <= 5; i++) {
			for (int j = i + 1; j <= i + 1; j++) {
				if (tableDeck[i]->getValue() + 1 == tableDeck[j]->getValue()) {
					straight = true;
					counter++;
				}
				else if (tableDeck[i]->getValue() == tableDeck[j]->getValue()) {
					counter = counter;

				}
				else {
					straight = false;
					return straight;
				}
			}
		}
	}
	if (counter < 4)
		straight = false;

	return straight;

}


bool Game::Flush()
{

	bool flush = false;
	int SuitCounter = 0;
	for (int i = 0; i < 7; i++) {
		if (SuitCounter >= 5) {
			flush = true;
			break;
		}
		SuitCounter = 0;
		for (int j = 0; j < 7; j++) {
			if (tableDeck[i]->getSuit() == tableDeck[j]->getSuit()) {
				SuitCounter++;


			}
		}
	}
	return flush;

}


bool Game::ThreeOfAKind()
{

	bool threeOfAKind = false;
	int counter = 0;

	for (int i = 0; i < 7; i++) {
		if (counter == 3) {
			threeOfAKind = true;
			break;
		}
		counter = 0;

		for (int j = 0; j < 7; j++) {
			if (tableDeck[i]->getValue() == tableDeck[j]->getValue()) {
				counter++;
			}
			else
				counter = counter;
		}
	}
	return threeOfAKind;
}

bool Game::TwoPair()
{
	int pairCounter = 0;
	int pairNumber = 0;
	int pairs = 0;
	for (int i = 0; i < 7; i++)
	{
		if (pairCounter == 2)
		{
			pairNumber = tableDeck[i]->getValue();
			pairs++;
		}
		pairCounter = 0;
		for (int j = 0; j < 7; j++)
		{
			if (tableDeck[i]->getValue() == tableDeck[j]->getValue()) {
				if (tableDeck[i]->getValue() != pairNumber) {
					pairCounter++;

				}

			}
		}
	}

	if (pairs == 2)
	{
		return true;
	}
	else
		return false;

}



bool Game::Pair()
{
	bool pair = false;
	int counter = 0;

	for (int i = 0; i < 7; i++) {
		if (counter == 2) {
			pair = true;
			break;
		}
		counter = 0;

		for (int j = 0; j < 7; j++) {
			if (tableDeck[i]->getValue() == tableDeck[j]->getValue()) {
				counter++;
			}
			else
				counter = counter;
		}
	}
	return pair;
}

bool Game::HighestCard()
{

	return true;
}
