#include "Card.h"

using namespace std;

Card::Card()
{
    isAlreadyUsed = false;
    value = 0;
    suit = undefined;
}

void Card::Display()
{
    if ((value >= 2) && (value <= 10)) {
        cout << value;
    }
    switch (value) {
    case 11:
        cout << "J";
        break;
    case 12:
        cout << "Q";
        break;
    case 13:
        cout << "K";
        break;
    case 14:
        cout << "Ace";
    }
    switch (this->suit) {
    case clubs:
        cout << " of clubs";
        break;
    case diamonds:
        cout << " of diamonds";
        break;
    case spades:
        cout << " of spades";
        break;
    case hearts:
        cout << " of hearts";
        break;
    }
}

void Card::setValue(int value)
{
    this->value = value;

}

void Card::setSuit(Suit suit)
{
    this->suit = suit;
}

int Card::getValue()
{
    return value;
}

Suit Card::getSuit()
{
    return suit;
}
