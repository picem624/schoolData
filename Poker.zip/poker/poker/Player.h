#pragma once
#include"Card.h"
#include<string>;

enum handType
{
	royalFlush, straightFlush, fourOfAKind, fullHouse,
	FLUSH, straight, threeOfAKind, twoPair, PAIR, highestCard
};

using namespace std;
class Player
{
public:
	int getBet();
	void setBet(int bet);
	Player(string name, int money, bool isSmallBlind);
	bool getAllIn();
	void setSmallBlind(bool boolean);
	bool getSmallBlind();
	void setAllIn(bool boolean);
	void setHandRankType(handType type);
	handType getHandRankType();
	void setHandRanking(int rank);
	int getHandRanking();
	void setMoney(int money);
	int getMoney();


	void setName(string Name);
	string getName();
	Card getCardArray(int index);
	Card *getCardArrayB(int index);
	void setCardInArray(int i,Card *card);
	bool getHasFold();
	void setHasFold(bool boolean);


	void setHighestCard(Card* card);
	Card* getHighestCard();
	void setTotalbet(int bet);
	int getTotalBet();
	void setHandsValue(int value);
	int getHandsValue();
	void setHandArray(int i ,Card* card);
	Card *getHandsArray(int i);

private:
	Card *cards[2];
	Card* handtoDisplay[7];
	Card* highestCard;
	handType hand;
	string Name;
	bool isSmallBlind;
	int bet;
	int totalBet;
	int handRank;
	int Money;
	int handsValue;
	bool isAllIn;
	bool hasFold;
	

};

